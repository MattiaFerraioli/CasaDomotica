﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace CasaDomotica

{

    class GestioneDB
    {
        MySqlConnection mcon = new MySqlConnection("server = localhost; user id = root; database = domotica; password= '';");
        MySqlCommand mcd, mcd1;
        MySqlDataReader mdr, mdr1;

        //apro la connessione
        public void ApriConnessione()
        {
            if (mcon.State == ConnectionState.Closed)
            {
                mcon.Open();
            }
        }

        //Chiudo la connessione
        public void ChiudiConnessione()
        {
            if (mcon.State == ConnectionState.Open)
            {
                mcon.Close();
            }
        }

        //Eseguo l'inserimento
        public void ExecuteQuery(string q)
        {
            ApriConnessione();
            try
            {
                mcd = new MySqlCommand(q, mcon);
                if (mcd.ExecuteNonQuery() == 1)
                {
                    //MessageBox.Show("Query Eseguita");
                }
                else
                {
                    //MessageBox.Show("Query Non Eseguita");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                mcon.Close();
            }
        }

        public void azioneTemperatura(string t)
        {
            //manca ora
            string data = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
            string ora = DateTime.Now.TimeOfDay.ToString();

            string q = "INSERT INTO azione (Tipo, Data,Ora,Valore, IDDispositivo) values (\"rilevazioneT\", \" "+data+" \",\" " +ora+" \",\" "+ t + " \" ,\"1\")";
            ExecuteQuery(q);
        }

        public bool login(string nome)
        {
           ApriConnessione();

            string q = "SELECT Username FROM utente";

            mcd = new MySqlCommand(q, mcon);
            mdr = mcd.ExecuteReader();

            bool controllo = false;

            while (mdr.Read())
            {
                if (nome == mdr["Username"].ToString())
                {
                    controllo = true;
                    break;
                }
                else
                {
                    controllo = false;
                }
            }

            //if (controllo == true)
            //{
            //    MessageBox.Show("Login Efettuata");
            //}
            //else
            //{
            //    MessageBox.Show("Correggi il nome immesso oppure effettua la registrazione");
            //}

            ChiudiConnessione();

            return controllo;
        }

        //Verifica Password
        public bool Controlla(string nome, string password)
        {
            bool controlla = false;

            //ApriConnessione();

            string q = "SELECT Password from utente WHERE Username = '" + nome + "'";

            mcd = new MySqlCommand(q, mcon);
            mdr = mcd.ExecuteReader();

            string sb = CreateMD5(password);
            //MD5 md5 = MD5.Create();

            //byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(password);

            //byte[] hash = md5.ComputeHash(inputBytes);

            //StringBuilder sb = new StringBuilder();

            //for (int i = 0; i < hash.Length; i++)
            //{

            //    sb.Append(hash[i].ToString("x2"));

            //}


            while (mdr.Read())
            {
                if (sb== mdr["Password"].ToString())
                {
                    controlla = true;
                    break;
                }
                else
                {
                    controlla = false;
                }
            }


            //ChiudiConnessione();

            return controlla;
        }

        public static string CreateMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Convert the byte array to hexadecimal string
                StringBuilder sb= new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }

        public bool controlloCodice(string cod)
        {
            bool controlla = false;
            
            ApriConnessione();

            string q = "SELECT CodProdotto FROM codice WHERE Usata = 0 AND CodProdotto=" + cod + "";

            mcd = new MySqlCommand(q, mcon);
            mdr = mcd.ExecuteReader();

            while (mdr.Read())
            {
                if (cod == mdr["CodProdotto"].ToString())
                {
                    controlla = true;
                    break;
                }
            }
            
            ChiudiConnessione();
            return controlla;
        }

        public bool Salva(TextBox username, TextBox email, TextBox password, TextBox cPassword, TextBox codice)
        {
            
            string data = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
            RegexMetodi r = new RegexMetodi();
            bool controllo = false;
            string cod = codice.Text;
            
            if (r.IsValidEmail(email.Text) == true && password.Text == cPassword.Text && controlloCodice(cod)==true )
            {
                ApriConnessione();

                string q = "SELECT ID FROM utente WHERE Username=\""+username.Text+"\"";

                mcd = new MySqlCommand(q, mcon);
                mdr = mcd.ExecuteReader();

               
                string q1 = "INSERT INTO utente (Username, Email, Password, DataReg) values(\"" + username.Text + "\" ,\"" + email.Text + "\",\"" + CreateMD5(password.Text) + "\",\"" + data + "\")";
                
                ExecuteQuery(q1);

                string q2 = "INSERT INTO codice (IDUtente,Usata) values (\"" + mdr["ID"] + "\",\"" + 1 + "\")";
                ExecuteQuery(q2);

                controllo = true;
            }
            else
                MessageBox.Show("Email non valida o password non corrispondenti");
            

            ChiudiConnessione();

            return controllo;
        }
    }
}
