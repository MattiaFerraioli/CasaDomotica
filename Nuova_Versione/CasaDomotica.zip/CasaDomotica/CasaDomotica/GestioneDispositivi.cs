﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CasaDomotica
{
    public partial class GestioneDispositivi : Form
    {
        public GestioneDispositivi()
        {
            InitializeComponent();
            pictureBox2.Load("D:\\MATURA\\CasaDomotica\\Button-Turn-On-icon.png");  //allarme
            label6.Text = "Acceso";
            pictureBox4.Load("D:\\MATURA\\CasaDomotica\\Button-Turn-On-icon.png");  //luce
            label7.Text = "Acceso";
            pictureBox3.Load("D:\\MATURA\\CasaDomotica\\Button-Turn-On-icon.png");  //fumo
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            Gorla g = new Gorla();
            GestioneDB c = new GestioneDB();
            string temperatura;
            temperatura = g.Leggi("temperatura");
            labelTemperatura.Text = temperatura;

            c.ApriConnessione();
            c.azioneTemperatura(temperatura);
            c.ChiudiConnessione();
        }

        private void pictureBox4_Click(object sender, EventArgs e) //LUCE
        {
            string imgPath = pictureBox4.ImageLocation;
            if (imgPath == "D:\\MATURA\\CasaDomotica\\Button-Turn-On-icon.png")
            {
                DialogResult dr = MessageBox.Show("Vuoi spegnere la luce?", "", MessageBoxButtons.YesNo);
                switch (dr)
                {
                    case DialogResult.Yes:
                        pictureBox4.Load("D:\\MATURA\\CasaDomotica\\power-off.png");
                        label7.Text = "Spento";
                        break;
                    case DialogResult.No: break;
                }
            }
            else
            {
                DialogResult dr = MessageBox.Show("Vuoi accendere la luce?", "", MessageBoxButtons.YesNo);
                switch (dr)
                {
                    case DialogResult.Yes:
                        pictureBox4.Load("D:\\MATURA\\CasaDomotica\\Button-Turn-On-icon.png");
                        label7.Text = "Acceso";
                        break;
                    case DialogResult.No: break;
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e) //ALLARME
        {
            string imgPath = pictureBox2.ImageLocation;

            if (imgPath == "D:\\MATURA\\CasaDomotica\\Button-Turn-On-icon.png")
            {
                DialogResult dr = MessageBox.Show("Vuoi spegnere l'allarme?", "", MessageBoxButtons.YesNo);
                switch (dr)
                {
                    case DialogResult.Yes:
                        pictureBox2.Load("D:\\MATURA\\CasaDomotica\\power-off.png");
                        label6.Text = "Spento";
                        break;
                    case DialogResult.No: break;
                }
            }
            else
            {
                DialogResult dr = MessageBox.Show("Vuoi accendere l'allarme?", "", MessageBoxButtons.YesNo);
                switch (dr)
                {
                    case DialogResult.Yes:
                        pictureBox2.Load("D:\\MATURA\\CasaDomotica\\Button-Turn-On-icon.png");
                        label6.Text = "Acceso";
                        break;
                    case DialogResult.No: break;
                }
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)  //FUMO
        {
            string imgPath = pictureBox3.ImageLocation;
            if (imgPath == "D:\\MATURA\\CasaDomotica\\Button-Turn-On-icon.png")
            {
                DialogResult dr = MessageBox.Show("Vuoi spegnere il sensore anti-fumo?", "", MessageBoxButtons.YesNo);
                switch (dr)
                {
                    case DialogResult.Yes:
                        pictureBox3.Load("D:\\MATURA\\CasaDomotica\\power-off.png");
                        break;
                    case DialogResult.No: break;
                }
            }
            else
            {
                DialogResult dr = MessageBox.Show("Vuoi accendere il sensore anti-fumo?", "", MessageBoxButtons.YesNo);
                switch (dr)
                {
                    case DialogResult.Yes:
                        pictureBox3.Load("D:\\MATURA\\CasaDomotica\\Button-Turn-On-icon.png");
                        break;
                    case DialogResult.No: break;
                }
            }
        }



    }
}
