﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace CasaDomotica
{
    class Gorla
    {
        public string Leggi(string sensore)
        {
            //Qui parte la seriale
            //interrogo l'arduino sul sensore che mi serve
            //restituisco il valore ottenuto

            Console.WriteLine("Inserisci " + sensore +": ");
            string risposta = Console.ReadLine();
            return risposta;
        }

        public void Esegui(string sensore, string azione)
        {

        }
    }
}
