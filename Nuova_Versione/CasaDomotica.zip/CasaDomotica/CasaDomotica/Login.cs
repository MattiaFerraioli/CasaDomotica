﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Forms;

namespace CasaDomotica
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Registrazione r = new Registrazione();
            
            this.Hide();

            r.ShowDialog();
            //
            //this.Hide();
            
        }

        private void button2_Click(object sender, EventArgs e) //btnLogin
        {
            GestioneDispositivi gd = new GestioneDispositivi();
            GestioneDB gdb = new GestioneDB();

            if (gdb.login(textBox3.Text) == true && gdb.Controlla(textBox3.Text, textBox4.Text) == true)
            {
                this.Hide();
                gd.ShowDialog();
            }
            else
            {
                MessageBox.Show("Username o password non corretti");
            }
                
        }

        
    }
}
