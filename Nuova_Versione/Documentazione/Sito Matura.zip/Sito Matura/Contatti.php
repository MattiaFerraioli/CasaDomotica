<html>
	<head>
		<title>Casa domotica: Contatti</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>
		<div id="contatti">
			<div class="contacts_area" >
			<form>
			</br></br>
				<h2> Andrea Bestetti</h2></br>
				<h2> Alberto Galimberti</h2></br>
				<h2> Andrea Gorla</h2></br>
				<h2> Mattia Ferraioli</h2></br>
				<h2> Vincenzo Lazzara</h2></br>
			</form>
		</div>	
	</body>
</html>