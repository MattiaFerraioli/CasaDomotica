<html>
  <head></head>
  <body>
    <?php	
		session_start();
			$_SESSION['UtenteScelta']=$_POST['utente'];	
			$_SESSION['PasswordScelta']=$_POST['password'];
			$_SESSION['CodiceScelta']=$_POST['codice'];
			$fp=fopen('FileRegistrazione.txt', 'r');
			
			header("location: Valori.php");
	?>	
  </body>
</html>