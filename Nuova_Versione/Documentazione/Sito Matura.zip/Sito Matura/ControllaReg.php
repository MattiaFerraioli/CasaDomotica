<html>
  <head></head>
  <body> 
    <?php	
		$email = $_POST['EmailRegistra'];
		$nome=$_POST['NomeRegistra'];
		$psw = $_POST['PasswordRegistra'];
		$codice = $_POST['CodiceRegistra'];
		$radiobtn = $_POST['intrusione'];
		
		session_start();
			$_SESSION['email']=$email;
			$_SESSION['nome']=$nome;
			$_SESSION['psw']=$psw;
			$_SESSION['codice']=$codice;		
			$radio=$radiobtn;
	
			$fp=fopen('FileRegistrazione.txt', 'a+');
			fwrite($fp, $_SESSION['email'].";");
			fwrite($fp, $_SESSION['nome'].";");
			fwrite($fp, $_SESSION['psw'].";");
			fwrite($fp, $_SESSION['codice'].";");
			fwrite($fp, $radio.";");
			fwrite($fp, "\n");
			fclose($fp);
			header("location: Valori.php");			
	?>	
	
	
  </body>
</html>