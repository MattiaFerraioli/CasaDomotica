<html>
	<head>
		<title>Login</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>
		<div id="login">
			<form id="formLogin" action="ControllaLogin.php" method="POST">
			</br>
				<h2>BENTORNATO</h2></br>
				Nome utente:
				<input type="Text" name="utente" required size="20" placeholder="Nome"/></br></br>
				Password:
				<input type="Text" name="password" required size="30" placeholder="Password"/></br></br>
				Password:
				<input type="Text" name="codice" required size="30" placeholder="Codice"/></br></br>
				<input type="submit" value="Login" id="buttonLogin"/></br></br>
				Non sei ancora registrato? <a href="Registrati.php"> Registrati! </a>			
			</form>
		</div>	
	</body>
</html>