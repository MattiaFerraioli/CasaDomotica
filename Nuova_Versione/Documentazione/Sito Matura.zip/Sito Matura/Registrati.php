<html>
	<head>
		<title>Registrazione</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>
		<div id="registra">
			<form id="formRegistrazione" action="ControllaReg.php" method="POST">
			</br>
				<h2>REGISTRATI</h2></br>
				Email: 
				<input type="Text" name="EmailRegistra" id="EmailRegistra" placeholder="Email"/></br></br>
				Username: 
				<input type="Text" name="NomeRegistra" id="NomeRegistra"placeholder="Username"/></br></br>
				Password: 
				<input type="Text" name="PasswordRegistra" id="PasswordRegistra" placeholder="Password"/></br></br>
				Codice: 
				<input type="Text" name="CodiceRegistra" placeholder="Codice"/></br></br>
				Ricevere email in caso di intrusione?</br></br>
				<Input type = 'Radio' Name ='intrusione' id="intrusione" value= 'si'/> Si</br>
				<Input type = 'Radio' Name ='intrusione' id="intrusione" value= 'no'/> No</br></br>
				<input type="submit" value = "Registrati"/> <br/>
				Sei già registrato? <a href="Login.php"> Login! </a>
			</form>
			
		</div>
	</body>
</html>