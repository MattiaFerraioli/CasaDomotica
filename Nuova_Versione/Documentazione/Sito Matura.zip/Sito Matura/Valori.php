<html>
	<head>
		<title>Casa domotica</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>
		<?php	
		session_start();
			if(!isset($_SESSION['email']) && !isset($_SESSION['nome']) && !isset($_SESSION['psw']) && !isset($_SESSION['codice']))
				header("location: index.php");
		?>
		<div id="valori">
		<form id="formPrenotazione">
		</br>
			<label id="P_cliente">Email: </label><?php echo $_SESSION['email'];?></br>
			<label id="P_paese">Nome: </label><?php echo $_SESSION['nome'];?></br>
			<label id="P_paese">Codice: </label><?php echo $_SESSION['codice'];?></br>
		</form>
		</div>
	</body>
</html>	