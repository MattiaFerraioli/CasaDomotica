<html>
  <head></head>
  <body>
    <?php
		session_start();
		$_SESSION['user'] = $_POST['email'];

		header("location: loggato.html");
	  ?>
  </body>
</html>