<html>
  <head></head>
  <body>
    <?php
		session_start();
		include "connettiDB.php";
		$_SESSION['USER'] = $_POST['email'];
		$psw = MD5($_POST['password']);
		$psw= strtoupper ($psw);
		
		$query =" SELECT * FROM utente WHERE Username = \"".$_SESSION['USER']."\" AND Password =\"".$psw."\"";
		//echo $query;
		$risultato = mysqli_query($connessione,$query);
		
		//$rigHe = mysqli_fetch_row($risultato);

		if(mysqli_num_rows($risultato) == 0)
		{
			header("Location: index.php");
		}
			
		else
		{
			$queryInsert = " INSERT INTO sessione (Data,Ora) values (\"".date("Y-m-j", time())."\",\"".date("H:i", time())."\",\"";
			$aggiungi = mysqli_query($connessione,$queryInsert);
			header("Location: loggato.php");
		}
		
	  ?>
  </body>
</html>