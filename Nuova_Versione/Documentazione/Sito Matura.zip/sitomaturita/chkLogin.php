<html>
  <head></head>
  <body>
    <?php
		session_start();
		$_SESSION['USER'] = $_POST['email'];
		
		header("location: loggato.php");
	  ?>
  </body>
</html>