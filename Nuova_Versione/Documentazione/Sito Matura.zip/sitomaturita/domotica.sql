-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Giu 17, 2016 alle 10:19
-- Versione del server: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `domotica`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `azione`
--

CREATE TABLE IF NOT EXISTS `azione` (
  `ID` int(20) NOT NULL AUTO_INCREMENT,
  `Tipo` varchar(20) NOT NULL,
  `Data` date NOT NULL,
  `Ora` time NOT NULL,
  `Valore` int(5) NOT NULL,
  `IDSessione` int(10) NOT NULL,
  `IDDIspositivo` int(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dump dei dati per la tabella `azione`
--

INSERT INTO `azione` (`ID`, `Tipo`, `Data`, `Ora`, `Valore`, `IDSessione`, `IDDIspositivo`) VALUES
(1, 'RichiestaTemp', '2016-05-07', '08:00:00', 22, 1, 1),
(2, 'RichiestaTemp', '2016-05-07', '12:00:00', 28, 2, 1),
(3, 'RichiestaTemp', '2016-05-10', '18:00:00', 24, 3, 1),
(4, 'RichiestaTemp', '2016-04-29', '08:00:00', 18, 4, 1),
(5, 'Fumo', '2016-05-15', '10:00:00', 1, 5, 2),
(6, 'Presenza', '2016-05-30', '12:30:00', 1, 6, 3),
(7, 'RichiestaTemp', '2016-06-01', '08:00:00', 30, 6, 1),
(8, 'Presenza', '2016-06-06', '17:30:00', 1, 7, 3),
(9, 'Presenza', '2016-06-07', '19:00:00', 1, 8, 3),
(10, 'Presenza', '2016-06-06', '20:00:00', 1, 9, 3);

-- --------------------------------------------------------

--
-- Struttura della tabella `codice`
--

CREATE TABLE IF NOT EXISTS `codice` (
  `CodProdotto` varchar(7) NOT NULL,
  `Usata` int(1) NOT NULL,
  `IDUtente` int(10) NOT NULL,
  PRIMARY KEY (`CodProdotto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `dispositivo`
--

CREATE TABLE IF NOT EXISTS `dispositivo` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dump dei dati per la tabella `dispositivo`
--

INSERT INTO `dispositivo` (`ID`, `Nome`) VALUES
(1, 'Temperatura'),
(2, 'Fumo'),
(3, 'Presenza');

-- --------------------------------------------------------

--
-- Struttura della tabella `sessione`
--

CREATE TABLE IF NOT EXISTS `sessione` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Data` date NOT NULL,
  `Ora` time NOT NULL,
  `IDUtente` int(10) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `sessione_ibfk_1` (`IDUtente`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dump dei dati per la tabella `sessione`
--

INSERT INTO `sessione` (`ID`, `Data`, `Ora`, `IDUtente`) VALUES
(1, '2016-05-07', '08:00:00', 1),
(2, '2016-05-07', '12:00:00', 2),
(3, '2016-05-10', '18:00:00', 3),
(4, '2016-05-10', '08:00:00', 4),
(5, '2016-05-30', '12:30:00', 1),
(6, '2016-07-01', '08:00:00', 2),
(7, '2016-06-06', '17:30:00', 2),
(8, '2016-06-07', '19:00:00', 3),
(9, '2016-06-06', '20:00:00', 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `utente`
--

CREATE TABLE IF NOT EXISTS `utente` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(20) NOT NULL,
  `Cognome` varchar(20) NOT NULL,
  `Username` varchar(10) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `DataReg` date NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dump dei dati per la tabella `utente`
--

INSERT INTO `utente` (`ID`, `Nome`, `Cognome`, `Username`, `Email`, `Password`, `DataReg`) VALUES
(1, 'Andrea', 'Gorla', 'Gorlaz', 'gorlaz@gmail.com', 'ciao', '2016-05-01'),
(2, 'Vincenzo', 'Lazzara', 'Lazza', 'lazza@gmail.com', 'ciao1', '2016-05-02'),
(3, 'Andrea', 'Bestetti', 'Beste', 'beste@gmail.com', 'ciao2', '2016-05-09'),
(4, 'Mattia', 'Ferraioli', 'Speche', 'Speche@gmail.com', 'ciao3', '2016-05-02');

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `sessione`
--
ALTER TABLE `sessione`
  ADD CONSTRAINT `sessione_ibfk_1` FOREIGN KEY (`IDUtente`) REFERENCES `utente` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
