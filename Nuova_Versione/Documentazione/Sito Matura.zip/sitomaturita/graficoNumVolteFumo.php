<?php
//Quante volte si � attivato l'antifurto
include("phpgraphlib.php");
include("connettiDB.php");
//mysqli_select_DB("domotica");

$graph = new PHPGraphLib(1000,800);
$query = "SELECT count(*) as conta,Data 
			FROM azione 
			where IDDispositivo='2'
			group by Data";
//data='2016-05-07' 
//echo "query: ". $query;
$res=mysqli_query($connessione,$query) or die("errore query");

while($result_row = mysqli_fetch_array($res))
{
	$data[$result_row['Data']] =  $result_row['conta'] ;
}

$graph->addData($data);

$graph->setTitle("Rilevazioni fumo");
$graph->setTextColor("red");
$graph->createGraph();
?>