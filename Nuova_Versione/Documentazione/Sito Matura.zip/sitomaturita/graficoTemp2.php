<?php
//Temperatura con istogramma
include("phpgraphlib.php");
include("connettiDB.php");
//mysqli_select_DB("domotica");

$graph = new PHPGraphLib(1000,800);
//$data="2016-05-07";
$query = "SELECT Valore,data 
			FROM azione 
			where IDDispositivo='1'";
//data='2016-05-07' 
//echo "query: ". $query;
$res=mysqli_query($connessione,$query) or die("errore query");

while($result_row = mysqli_fetch_array($res))
{
	$data[$result_row['data']] =  $result_row['Valore'] ;
}

$graph->addData($data);

$graph->setTitle("Andamento Temperatura");
$graph->setTextColor("red");
$graph->createGraph();
?>