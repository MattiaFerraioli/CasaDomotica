<?php
/*
    $view = "day"; // Can be month or day.
    $path = "C://wamp/www/progettomaturitaphp"; // Relative or absolute path to calendar folder. Must have a trailing slash.
    
    // Do not edit the rest unless you know what you're doing
    echo '<link rel="stylesheet" title="Default" type="text/css" href="' . $path . 'style.css" />';
    if ($view == 'month' || isset($_GET['view'])) {
        echo '<script src="' . $path . 'e_edit.js" type="text/javascript"></script>';
    }
// DO NOT EDIT
if (!isset($_GET['view'])) {
    include $path . 'embed/' . $view . '.php';
}
else {
    include $path . 'embed/' . $_GET['view'] . '.php';
}
*/
//Temperatura con istogramma
include("phpgraphlib.php");
include("connettiDB.php");
//mysqli_select_DB("domotica");

$graph = new PHPGraphLib(1000,800);

$query = "SELECT avg(Valore), data 
			FROM azione 
			where IDDispositivo='0'
			group by data";
 
//echo "query: ". $query;
$res=mysqli_query($connessione,$query) or die("errore query");

while($result_row = mysqli_fetch_array($res))
{
	$data[$result_row['data']] =  $result_row['avg(Valore)'] ;
}

$graph->addData($data);

$graph->setTitle("Andamento Temperatura");
$graph->setTextColor("red");
$graph->createGraph();
?>