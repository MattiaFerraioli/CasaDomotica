<html>
  <head></head>
  <body>
    <?php
			session_start();
		$_SESSION['email']=$_POST['EmailRegistra'];
		$_SESSION['nome']=$_POST['NomeRegistra'];
		$_SESSION['psw']=$_POST['PasswordRegistra'];
			$fp=fopen('FileRegistrazione.txt', 'a+');
			fwrite($fp, $_SESSION['email'].";".$_SESSION['nome'].";".$_SESSION['psw'].";");
			fclose($fp);
			header("location: Valori.php");
	?>	
  </body>
</html>