<html>
	<head>
		<title>Casa domotica: Info</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>