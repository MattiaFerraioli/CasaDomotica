<html>
	<head>
		<title>Casa domotica</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>
		<div id="index">
			<div class="menu_area" >
			<form>
				<a href='Informazioni.php' class="info">
						info
				</a>
				
				<a href='Contatti.php' class="contatti">
						contatti
				</a>
				
				<a href='Descrizione.php' class="descrizione">
						descrizione
				</a>
				
					</br></br></br></br></br></br>
					
					<h1>Casa domotica</h1></br></br>
					<a href="Login.php" class="readmoreIndex"> Login </a>
					<a href="Registrati.php" class="readmoreIndex"> Registrati </a>				
			</form>
		</div>	
	</body>
</html>