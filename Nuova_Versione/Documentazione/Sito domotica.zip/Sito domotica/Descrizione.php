<html>
	<head>
		<title>Casa domotica</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>
		<div id="index">
					<h1>Casa domotica</h1></br>
					La casa domotica ha il compito di gestire i sensori presenti in casa (temperatura, fumo e presenza).</br>
					La casa pu� essere gestita non solo direttamente dai pulsanti presenti sulla scheda, ma anche a distanza attraverso una connessione internet.</br>
					Per poter essere gestita a distanza deve essere collegata, mediante la Shield Arduino UNO, ad un PC sul quale un apposito software (sviluppato in linguaggio java) ha il compito di inviare i dati (presenza di intrusi, temperatura dell�ambiente, presenza di fumo) ad uno script in linguaggio php presente sul server, che si occupa di salvare i dati ricevuti in un database.</br>
					Il software Java, oltre ad inviare i dati, si occupa anche di ricevere i comandi, sempre attraverso il collegamento con uno script php, che sono stati salvati in un�apposita tabelladel database, dopo essere stati richiesti dai dispositivi mobili o dal pannello di controllo presente sul sito web.</br>
					Per poter gestire la casa e se si vuole ricevere un�e-mail in caso di una rivelazione di intrusione, bisogna eseguire una registrazione sul sito.</br></br>				
		</div>	
	</body>
</html>