<html>
	<head>
		<title>Login</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>
		<div id="login">
			<form id="formLogin" >
				<h2>BENVENUTO</h2></br>
				Nome utente:
				<input type="Text" name="cliente" required size="20" placeholder="Nome"/></br></br>
				Password:
				<input type="Text" name="indirizzo" required size="30" placeholder="Password"/></br></br>
				<input type="button" value="Login" id="buttonLogin"/></br></br>
				<input type="button" value="Registrati" id="buttonRegistratiLogin" onclick="window.location.href='Registrati.php';"/>			
			</form>
		</div>	
	</body>
</html>