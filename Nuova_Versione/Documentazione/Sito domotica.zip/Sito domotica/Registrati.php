<html>
	<head>
		<title>Registrazione</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>
		<div id="registra">
			<form id="form2" action = "ChkRegistra.php" method = "POST">
				<h2>REGISTRAZIONE</h2></br>
				Email: <input type="Text" name="EmailRegistra" required size="40" placeholder="Email"/></br></br>
				Username: <input type="Text" name="NomeRegistra" required size="10" placeholder="Username"/></br></br>
				Password: <input type="Text" name="PasswordRegistra" required size="20" placeholder="Password"/></br></br>
				Conferma password: <input type="Text" name="ConfermaRegistra" required size="20" placeholder="Conferma password"/></br></br>
				Ricevere email in caso di intrusione?</br></br>
				<Input type = 'Radio' Name ='intrusione' value= 'si'/> Si</br>
				<Input type = 'Radio' Name ='intrusione' value= 'no'/> No</br></br>
				<input type="button" value="Login" id="buttonLogin" onclick="window.location.href='Login.php';"/></br></br>
				<input type = "Submit" name="Registrati" value = "Registrati" /> <br/>
			</form>
			
		</div>
	</body>
</html>