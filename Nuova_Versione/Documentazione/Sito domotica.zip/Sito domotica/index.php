<html>
	<head>
		<title>Casa domotica</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="Script.js"></script>
	</head>
	<body>
		<div id="index">
			<div class="menu_area" >
			
				<a href='Informazioni.php' class="info">
						info
				</a>
				
				<a href='Contatti.php' class="contatti">
						contatti
				</a>
				
				<a href='Descrizione.php' class="descrizione">
						descrizione
				</a>
				
					</br></br></br></br></br>
					
					<h1>Casa domotica</h1></br>
					<input type="button" value="Login" id="buttonLogin" onclick="window.location.href='Login.php';"/></br></br>
					<input type="button" value="Registrati" id="buttonRegistratiLogin" onclick="window.location.href='Registrati.php';"/>				
			</form>
		</div>	
	</body>
</html>